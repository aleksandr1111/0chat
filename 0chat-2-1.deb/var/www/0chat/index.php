
<html>
	<meta charset="utf-8">
	<head>
		<title>
			0chat
		</title>
	</head>
	<?php
		/*
			Этот файл (index.php) всегда первым попадается на пути сервера, ).
			Деление окна на две равные части по горизонтали.
			Вызов кода на исполнение из файла chat1.php для верхней части окна.
			Вызов кода на исполнение из файла chat2.php для нижней части окна.
		*/
	?>
	<frameset rows="51%,*">
		<frame name="chat1" src="chat1.php">
		<frame name="chat2" src="chat2.php">
	</frameset>
</html>

