
<html>
	<meta charset="utf-8">
	<meta http-equiv="refresh" content="11">
	<?php
		/*
			Вывод пользователю чата лога чата из файла лога сообщений (базы данных) чата (log1.txt).
		*/
		$chat2=file_get_contents("log1.txt");
		echo $chat2;
	?>
</html>

