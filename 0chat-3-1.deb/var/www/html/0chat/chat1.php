
<html>
	<meta charset="utf-8">
	<?php
		/*
			Ссылка на файл (0chat1.php) с текстом послания для пользователей чата, от автора чата.
		*/
	?>
	<a href="0chat1.php">
		0chat
	</a>
	<br>
	<?php
		/*
			Вывод поля для ввода текста сообщения, вывод кнопок для действий над текстом сообщения из поля для ввода текста сообщения.
		*/
	?>
	<form method="post" action="chat1.php">
	<input type="text" name="chat1" size="1111" maxlength="1111" value="" autofocus>
	<br>
	<input type="reset" value="delete">
	<input type="submit" value="ok">
	<br>
	<?php
		/*
			Отправка (запись) данных чата в файл лога чата (или в файл базы данных чата - log1.txt).
		*/
		$fajl1="log1.txt";
		$tekst1=$_REQUEST["chat1"];
		$data1=`date`;
		$chat1="<br>".">".$data1.">".$tekst1;
		/*
			Вывод последнего введённого текста сообщеия (видно только тому пользователю чата, который отправил серверу этот текст этого сообщения).
		*/
		echo $chat1;
		/*
			Контроль (слежение) за массой (размером) файла лога чата (или файла базы данных чата - log1.txt).
		*/
		$fajl3=1111;
		$fajl2=filesize($fajl1);
		if($fajl2>$fajl3)
			{
				unlink($fajl1);
			}
		file_put_contents($fajl1,$chat1,FILE_APPEND);
	?>
</html>

