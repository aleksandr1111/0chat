
<html>
<meta charset="utf-8">
<meta http-equiv="refresh" content="10">
<?php
$chat2=file_get_contents("log1.txt");
echo $chat2;
?>
</html>

