
<html>
<meta charset="utf-8">
<a href="0chat1.html">
0chat
</a>
<br>
<form method="post" action="chat1.php">
<input type="text" name="chat1" size="120" maxlength="2000" value="">
<br>
<input type="reset" value="delete">
<input type="submit" value="ok">
<br>
<?php
$fajl1="log1.txt";
$tekst1=$_REQUEST["chat1"];
$data1=`date`;
$chat1="<br>".">".$data1.">".$tekst1;
echo $chat1;
$fajl3=10000;
$fajl2=filesize($fajl1);
if($fajl2>$fajl3)
{
unlink($fajl1);
}
file_put_contents($fajl1,$chat1,FILE_APPEND);
?>
</html>

