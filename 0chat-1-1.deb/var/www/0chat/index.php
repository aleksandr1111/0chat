
<html>
<meta charset="utf-8">
<head>
<title>
0chat
</title>
</head>
<frameset rows="50%,*">
<frame name="chat1" src="chat1.php">
<frame name="chat2" src="chat2.php">
</frameset>
</html>

